package krych.bartosz.crossword;

public enum Orientation {
    HORIZONTAL,
    VERTICAL
}

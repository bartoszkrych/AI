package krych.bartosz.crossword.heuristic.domain;

import krych.bartosz.abstra.DomHeuristic;
import krych.bartosz.crossword.CrosswordVariable;

import java.util.List;

public class CrossSeqDomHeuristic implements DomHeuristic<CrosswordVariable> {
    @Override
    public void sort(List<CrosswordVariable> variables) {
    }
}

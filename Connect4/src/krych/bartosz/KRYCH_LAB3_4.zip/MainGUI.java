package krych.bartosz;

import krych.bartosz.gui.GameGUI;

public class MainGUI {
    public static void main(String[] args) {
        GameGUI connect4 = new GameGUI();
        connect4.createNewGame();
    }
}

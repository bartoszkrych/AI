package krych.bartosz.interfaces;

import krych.bartosz.classes.State;

public interface FitnessFunction {
    Integer calcFitness(State state);
}

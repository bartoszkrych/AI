package krych.bartosz.interfaces;

import krych.bartosz.classes.State;

public interface EstimateFunction {
    Integer makeEstimate(State state);
}
